import cv2
import numpy as np
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'

# Load Yolo
net = cv2.dnn.readNet("yolov4-obj.cfg","yolov4-obj_last.weights")
#net = cv2.dnn.readNet("yolov3.weights", "yolov3.cfg")
fourcc = cv2.VideoWriter_fourcc(*'MP4V')
outp = cv2.VideoWriter('output.mp4', fourcc, 20.0, (320,240))


classes = []
with open("classes.names", "r") as f:
    classes = [line.strip() for line in f.readlines()]
layer_names = net.getLayerNames()
output_layers = [layer_names[i[0] - 1] for i in net.getUnconnectedOutLayers()]
colors = np.random.uniform(0, 255, size=(len(classes), 3))

# Loading image
cap = cv2.VideoCapture('1.mp4')
number=0
while cap:
    
    ret, frame = cap.read()
    if ret == True:
        img = cv2.resize(frame, None, fx=0.4, fy=0.4)
        #img = cv2.resize(frame,(416, 416))
        height, width, channels = img.shape

        # Detecting objects
        blob = cv2.dnn.blobFromImage(img, 0.00392, (416, 416), (0, 0, 0), True, crop=False)

        net.setInput(blob)
        outs = net.forward(output_layers)

        # Showing informations on the screen
        class_ids = []
        confidences = []
        boxes = []

        for out in outs:
            for detection in out:
                scores = detection[5:]
                class_id = np.argmax(scores)
                confidence = scores[class_id]
                if confidence > 0.5:
                    # Object detected
                    center_x = int(detection[0] * width)
                    center_y = int(detection[1] * height)
                    w = int(detection[2] * width)
                    h = int(detection[3] * height)

                    # Rectangle coordinates
                    x = int(center_x - w / 2)
                    y = int(center_y - h / 2)

                    boxes.append([x, y, w, h])
                    confidences.append(float(confidence))
                    class_ids.append(class_id)

        indexes = cv2.dnn.NMSBoxes(boxes, confidences, 0.5, 0.4)
        print(indexes)
        font = cv2.FONT_HERSHEY_PLAIN
        for i in range(len(boxes)):
            if i in indexes:
                x, y, w, h = boxes[i]
                label = str(classes[class_ids[i]])
                color = colors[class_ids[i]]
            

                cv2.rectangle(img, (x, y), (x + w, y + h), color, 2)
                if label=="plate":
                    
                    img_ = cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
                    img_ = img_[y:y+h, x:x+w]
                    text = pytesseract.image_to_string(img_,lang="eng")
                    #print(text)
                    cv2.putText(img, label, (0, height-20), font, 3, [0,0,255], 3)
                    cv2.putText(img, text, (150, height-20), font, 3, [0,0,255], 3)

                else:
                    cv2.putText(img, label, (0+400, height-20), font, 3, color, 3)
        img = cv2.resize(img,(320,240))            
        cv2.imshow("Image", img)
        outp.write(img)

        if cv2.waitKey(25) & 0xFF == ord('q'):
          break
        #cv2.waitKey(0)
cv2.destroyAllWindows()
